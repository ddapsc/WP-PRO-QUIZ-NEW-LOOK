//jQuery(document).ready(function() {
//    
//	"use strict";
//	
//	jQuery('a.add_to_cart_button').on('click', function() {
//		var link = this;
//	
//		jQuery(link).closest('.product').find('a img').animate({opacity: 0.7});
//		setTimeout(function(){
//			
//			jQuery(link).closest('.product').addClass('added-to-cart-check');
//
//			setTimeout(function(){
//				jQuery(link).closest('.product').find('a img').animate({opacity: 1});
//			}, 1000);
//		}, 1000);	
//		
//		var msgSuccess = jQuery('.cart-wrap').attr('data-success');
//		var productName = jQuery(this).parents('li').find('h3').text();
//		jQuery('.cart-note').html('<span><strong>'+ productName +'</strong> '+ msgSuccess +'</span>');	
//		
//	});
//	
//	
//	if(jQuery().magnificPopup){
//		// lightbox for gallery images
//		jQuery('.industify_fn_woo .images').each(function() {
//            jQuery(this).magnificPopup({
//				delegate: 'a.zoom, .woocommerce-product-gallery__image a',
//				type: 'image',
//				overflowY: 'auto',
//				fixedContentPos: false,
//				closeOnContentClick: false,
//				closeBtnInside: false,
//				mainClass: 'mfp-with-zoom mfp-img-mobile',
//				image: {
//					verticalFit: true,
//					titleSrc: function(item) {
//						return item.el.attr('title');
//					}
//				},
//				gallery: {
//					enabled: true
//				}
//			});	
//        });
//	}	
//	
//	
//	
//	jQuery('body').bind('added_to_cart', cart_note);
//	
//	function cart_note(){
//		setTimeout(function(){
//				jQuery('.industify_fn_topbar .cart-note').stop(true,true).fadeIn(400);
//				
//				setTimeout(function(){
//					jQuery('.industify_fn_topbar .cart-note').stop(true,true).fadeOut(400);
//				}, 2000);
//		}, 1200);
//	}
//
//	
//	jQuery('.industify_fn_topbar .cart-note').hover(function(){
//		clearTimeout();
//		jQuery(this).fadeOut(400);
//		jQuery(this).parent().find('.cart-nav > div.dropdown_widget_cart').stop(true,true).fadeIn(400);
//	});
//	
//	//cart dropdown
//	jQuery('.industify_fn_topbar div.cart-wrap').hover(function(){
//		jQuery(this).find('.cart-nav > div.dropdown_widget_cart').stop(true,true).fadeIn(400);
//		clearTimeout();
//		jQuery(this).find('.industify_fn_topbar .cart-note').fadeOut(400);
//	},function(){
//		jQuery(this).find('.cart-nav > div.dropdown_widget_cart').stop(true,true).delay(100).fadeOut(300);
//	});
//
//	jQuery('body').bind('added_to_cart', nav_cart);
//	
//	jQuery(document).ready(function() {
//        nav_cart();
//    });
//	
//	function nav_cart(){
//		if(!jQuery('.widget_shopping_cart_content .cart_list .empty').length && jQuery('.widget_shopping_cart_content .cart_list').length > 0 )  {
//			jQuery('.cart-wrap').addClass('has-products');
//		}
//	}
//	
//	
//	
//	// experiment
//	industify_fn_woo_shopReviews();
//	industify_fn_woo_productSingleH();
//	jQuery(window).on('resize',function(e){
//		e.preventDefault();
//		industify_fn_woo_productSingleH();
//	});
//	
//});
//function industify_fn_woo_shopReviews(){
//	"use strict";
//	var shopReview	= jQuery('a.woocommerce-review-link');
//	if(shopReview.length){
//		shopReview.on('click',function(e){
//			e.preventDefault();
//			var productID	= shopReview.attr('href');
//			var top 		= jQuery(productID).offset().top;
//			jQuery('body,html').animate({scrollTop: top}, 1100);
//		});
//	}
//	
//	// for create own design for empty cart
//	var cartEmpty 		= jQuery('p.cart-empty');
//	var returnToShop 	= jQuery('p.return-to-shop');
//	var returnHTML		= returnToShop.html();
//	var cartEmptyHTML	= cartEmpty.html();
//	if(cartEmpty.length){
//		returnToShop.empty();
//		cartEmpty.empty();
//		jQuery('.woocommerce').append('<div class="fn_cart-empty"><span>'+cartEmptyHTML+'</span><span>'+returnHTML+'</span>');
//	}
//	// for create own design for my-account
//	var myAccount 		= jQuery('.woocommerce-account .woocommerce-MyAccount-content');
//	if(myAccount.length){
//		myAccount.parent().wrapInner('<div class="industify_fn_woo_myaccount"><div><div class="inner">');
//	}
//	// for create own design for my-account -> login
//	var logIn			= jQuery('.woocommerce form.login');
//	var parentTitle		= logIn.parent().find('h2');
//	if(logIn.length){
//		parentTitle.hide();
//		logIn.wrap('<div class="industify_fn_woo_login"><div>').wrapInner('<div class="industify_fn_woo_login_inner"><div>');
//	}
//}
//function industify_fn_woo_productSingleH(){
//	"use strict";
//	
//	var leftSide 	= jQuery('.woocommerce div.product div.woocommerce-product-gallery');
//	var rightSide 	= jQuery('.woocommerce div.product div.summary');
//	var leftSideH	= leftSide.outerHeight();
//	var rightSideH	= rightSide.height();
//	var W			= jQuery(window).width();
//	
//	if(W > 1200){
//		if(leftSideH > rightSideH){
//			var abc		= (leftSideH - rightSideH) / 2;
//			rightSide.css({paddingTop:abc,paddingBottom:abc});
//		}
//	}else{
//		rightSide.css({paddingTop:'7%',paddingBottom:'7%'});
//	}
//	
//}



(function ($){

	"use strict";
	
    var IndustifyWoo 		= {
		
		cartWait: false,
		
		init: function(){
			this.magnificPopup();
			this.openCartBox__Woo();
			this.removeItemFromCart__Woo();
			this.addToCart();
			this.someCustomFunctions();
			this.removeXFromCart();
			this.checkCartBoxOffset();
			$('body').bind('added_to_cart removed_from_cart updated_cart_totals updated_wc_div', this.updateCart);
		},
		checkCartBoxOffset: function(){
			var cartBox			= $('.industify_fn_cartbox');
			var cartOpener		= $('.industify_fn_buy_nav a.buy_icon');
			if(cartBox.length && cartOpener.length){
				var W			= $(window).width();
				var leftOffset 	= cartOpener.offset().left;
				var width		= cartBox.width();
				if(leftOffset+width/2+cartOpener.width()/2 > W){
					cartBox.addClass('be_careful');
				}else{
					cartBox.removeClass('be_careful');
				}
				
			}
		},
		removeXFromCart: function(){
			$('.woocommerce table.shop_table td.product-remove a.remove,.woocommerce.widget_shopping_cart .cart_list li a.remove').text('');
		},
		someCustomFunctions: function(){
			
			// smooth scroll to review section
			var shopReview	= $('a.woocommerce-review-link');
			if(shopReview.length){
				shopReview.on('click',function(e){
//					e.preventDefault();
//					var productID	= shopReview.attr('href');
//					var top 		= $(productID).offset().top;
//					$('body,html').animate({scrollTop: top}, 1100);
					return false;
				});
			}

			// for create own design for empty cart
			var cartEmpty 		= $('p.cart-empty');
			var returnToShop 	= $('p.return-to-shop');
			var returnHTML		= returnToShop.html();
			var cartEmptyHTML	= cartEmpty.html();
			if(cartEmpty.length){
				returnToShop.empty();
				cartEmpty.remove();
				$('.woocommerce').append('<div class="fn_cart-empty"><span>'+cartEmptyHTML+'</span><span>'+returnHTML+'</span>');
			}
			// for create own design for my-account
			var myAccount 		= $('.woocommerce-account .woocommerce-MyAccount-content');
			if(myAccount.length){
				myAccount.parent().wrapInner('<div class="industify_fn_woo_myaccount"><div><div class="inner">');
			}
			// for create own design for my-account -> login
			var logIn			= $('.woocommerce form.login');
			var parentTitle		= logIn.parent().find('h2');
			if(logIn.length){
				parentTitle.hide();
				logIn.wrap('<div class="industify_fn_woo_login"><div>').wrapInner('<div class="industify_fn_woo_login_inner"><div>');
			}	
		},
		updateCart: function(){
//			var self		= this;
			var cartBox		= $('.industify_fn_cartbox');
			var counter		= $('.industify_fn_buy_nav a.buy_icon span');
			var pageFrom	= '';
			if($('body').hasClass('woocommerce-cart')){
				pageFrom	= 'cart';
			}
			if($('body').hasClass('woocommerce-checkout')){
				pageFrom	= 'checkout';
			}
			var requestData = {
				action: 'industify_fn_remove_item_from_cart',
				product_id: '',
				cart_item_key: '',
				pageFrom: pageFrom
			};

			$.ajax({
				type: 'POST',
				url: fn_ajax_object.fn_ajax_url,
				cache: true,
				data: requestData,
				success: function(data) {
					var fnQueriedObj 	= $.parseJSON(data); //get the data object
					cartBox.html(fnQueriedObj.industify_fn_data);
					counter.html(fnQueriedObj.count);
					IndustifyWoo.cartWait 		= false;
					IndustifyWoo.removeItemFromCart__Woo();
				},
				error: function() {
					IndustifyWoo.cartWait 		= false;
					console.log('Error');
				}
			});
		},
		addToCart: function(){
			$('a.add_to_cart_button').on('click', function() {
				var link 	= this;

				$(link).closest('.product').find('a img').animate({opacity: 0.7});
				setTimeout(function(){

					$(link).closest('.product').addClass('added-to-cart-check');

					setTimeout(function(){
						$(link).closest('.product').find('a img').animate({opacity: 1});
					}, 1000);
				}, 1000);
			});	
		},
		magnificPopup: function(){
			if($().magnificPopup){
				// lightbox for gallery images
				$('.industify_fn_woo .images').each(function() {
					$(this).magnificPopup({
						delegate: 'a.zoom, .woocommerce-product-gallery__image a',
						type: 'image',
						overflowY: 'auto',
						fixedContentPos: false,
						closeOnContentClick: false,
						closeBtnInside: false,
						mainClass: 'mfp-with-zoom mfp-img-mobile',
						image: {
							verticalFit: true,
							titleSrc: function(item) {
								return item.el.attr('title');
							}
						},
						gallery: {
							enabled: true
						}
					});	
				});
			}
		},
		
		checkIfCartHasBeenChangedSomewhere: function(){
			var self		= this;
			var pageFrom	= '';
			var cartBox		= $('.industify_fn_cartbox');
			var counter		= $('.industify_fn_buy_nav a.buy_icon span');
			if($('body').hasClass('woocommerce-cart')){
				pageFrom	= 'cart';
			}
			if($('body').hasClass('woocommerce-checkout')){
				pageFrom	= 'checkout';
			}
			var requestData = {
				action: 'industify_fn_remove_item_from_cart',
				product_id: '',
				cart_item_key: '',
				pageFrom: pageFrom
			};

			$.ajax({
				type: 'POST',
				url: fn_ajax_object.fn_ajax_url,
				cache: true,
				data: requestData,
				success: function(data) {
					var fnQueriedObj 	= $.parseJSON(data); //get the data object
					$('.industify_fn_hidden_info').remove();
					$('body').append('<div class="industify_fn_hidden_info">'+fnQueriedObj.subtotal+'</div>');
					if((cartBox.find('.fn_right').html() != $('.industify_fn_hidden_info').html() || counter.html() != fnQueriedObj.count) && cartBox.find('.fn_right').length && counter.html() > 0){
						cartBox.append(fnQueriedObj.update);
						cartBox.find('.fn_cartbox_updater').on('click',function(){
							cartBox.html(fnQueriedObj.industify_fn_data);
							counter.html(fnQueriedObj.count);
							IndustifyWoo.removeItemFromCart__Woo();
							return false;
						});
					}
					IndustifyWoo.cartWait 		= false;
				},
				error: function() {
					IndustifyWoo.cartWait 		= false;
					console.log('Error');
				}
			});
		},
		
		openCartBox__Woo: function(){
			var self			= this;
			var button			= $('.industify_fn_buy_nav a.buy_icon');
			var cartBox			= $('.industify_fn_cartbox');
			button.on('click',function(e){
				e.preventDefault();
				e.stopPropagation();
				if(cartBox.hasClass('opened')){
					cartBox.removeClass('opened');
					if($('#fp-nav').length){$('#fp-nav').removeClass('be_careful');}
				}else{
					cartBox.addClass('opened');
					if($('#fp-nav').length){$('#fp-nav').addClass('be_careful');}
					IndustifyWoo.checkIfCartHasBeenChangedSomewhere();
				}
				
				return false;
			});
			$(window).on('click',function(){
				cartBox.removeClass('opened');
				$('#fp-nav').removeClass('be_careful');
			});
			cartBox.on('click',function(e){
				e.stopPropagation();
			});
		},
		removeItemFromCart__Woo: function(){
			var self		= this;
			$('.fn_cartbox_delete_item').off().on('click', function (e){
    			e.preventDefault();
				IndustifyWoo.cartWait = true;
				var button	= $(this);
				var item	= button.closest('.fn_cartbox_item');
				var itemID	= item.data('id');
				var itemKey	= item.data('key');
				var cartBox	= $('.industify_fn_cartbox');
				var counter	= $('.industify_fn_buy_nav a.buy_icon span');
//				cartBox.block({
//					message: null,
//					overlayCSS: {
//						cursor: 'none'
//					}
//				});
				
				
				var requestData = {
					action: 'industify_fn_remove_item_from_cart',
					product_id: itemID,
					cart_item_key: itemKey
				};
				
				$.ajax({
					type: 'POST',
					url: fn_ajax_object.fn_ajax_url,
					cache: true,
					data: requestData,
					success: function(data) {
						var fnQueriedObj 	= $.parseJSON(data); //get the data object
						cartBox.html(fnQueriedObj.industify_fn_data);
						counter.html(fnQueriedObj.count);
						IndustifyWoo.cartWait 		= false;
						IndustifyWoo.removeItemFromCart__Woo();
					},
					error: function() {
						IndustifyWoo.cartWait 		= false;
						console.log('Error');
					}
				});
				return false;
			});
		}
	};
	
	
	
	// ready functions
	$(document).ready(function(){
		IndustifyWoo.init();
	});
	
	// resize functions
	$(window).on('resize',function(e){
		e.preventDefault();
		IndustifyWoo.checkCartBoxOffset();
	});
	
	// scroll functions
	$(window).on('scroll', function(e) {
		e.preventDefault();
    });
	
	
})(jQuery);