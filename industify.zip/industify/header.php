<!DOCTYPE html >
<html <?php language_attributes(); ?>><head>
<?php 
	global $industify_fn_option, $post;	
?>

<meta charset="<?php esc_attr(bloginfo( 'charset' )); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<?php wp_head(); ?>

</head>

<body 
<?php 
	if(isset($industify_fn_option)){
		if(isset($industify_fn_option["site_rtl"])){
			if($industify_fn_option["site_rtl"] == "enable"){
				body_class('industify-theme rtl');
			}else{
				body_class('industify-theme');
			}
		}else{
			body_class('industify-theme');
		}
	}else{
		body_class();
	}
?>
>

<?php 	
	// navigation skin
	$nav_skin = industify_fn_get_nav_skin();
	
	// since improvements
	if(isset($industify_fn_option)){
		$industify_theme 		= 'industify-theme';
	}else{
		$industify_theme		= '';
	}
	$tollFreeEnable 			= 'toll_free_disable';
	if(isset($industify_fn_option['topbar_switch']) && ($industify_fn_option['topbar_switch'] === 'enable')){
		$tollFreeEnable 		= 'toll_free_enable';
	}
	
	// from 1.1.8
	$mobMenuAutocollapse 		= 'disable';
	if(isset($industify_fn_option['mobile_menu_autocollapse'])){
		$mobMenuAutocollapse 	= $industify_fn_option['mobile_menu_autocollapse'];
	}
	
?>

<!-- WRAPPER ALL -->
<div class="industify_fn_wrapper_all <?php echo esc_attr($industify_theme);?> <?php echo esc_attr($tollFreeEnable);?>" 
	data-nav-skin="<?php echo esc_attr($nav_skin); ?>" 
	data-mobile-autocollapse="<?php echo esc_attr($mobMenuAutocollapse); ?>" 
	>

	<!-- WRAPPER -->
	<div class="industify_fn_wrapper">
	
		<?php get_template_part( 'inc/navigation/desktop-nav'); ?>

		<?php get_template_part( 'inc/navigation/mobile-nav'); ?>
		
		<?php 
			if(isset($industify_fn_option['sticky_nav_switcher'])){
				// check for sticky navigation and call him
				$sticky_switcher = $industify_fn_option['sticky_nav_switcher'];
				if($sticky_switcher === 'enable'){
					get_template_part( 'inc/navigation/sticky-nav');
				}
			}
				
		?>
		
		<!-- WRAPPER for HEIGHT -->
		<div class="industify_fn_wfh">
  		