<?php

get_header();

global $post, $industify_fn_option;
$industify_fn_pagetitle = '';
$industify_fn_top_padding = '';
$industify_fn_bot_padding = '';
$industify_fn_page_spaces = '';
$industify_fn_pagestyle = '';

if(function_exists('rwmb_meta')){
	$industify_fn_pagetitle 		= get_post_meta(get_the_ID(),'industify_fn_page_title', true);
	$industify_fn_top_padding 		= get_post_meta(get_the_ID(),'industify_fn_page_padding_top', true);
	$industify_fn_bot_padding 		= get_post_meta(get_the_ID(),'industify_fn_page_padding_bottom', true);
	
	$industify_fn_page_spaces = 'style=';
	if($industify_fn_top_padding != ''){$industify_fn_page_spaces .= 'padding-top:'.$industify_fn_top_padding.'px;';}
	if($industify_fn_bot_padding != ''){$industify_fn_page_spaces .= 'padding-bottom:'.$industify_fn_bot_padding.'px;';}
	if($industify_fn_top_padding == '' && $industify_fn_bot_padding == ''){$industify_fn_page_spaces = '';}
	
	// page styles
	$industify_fn_pagestyle 			= get_post_meta(get_the_ID(),'industify_fn_page_style', true);
}

// since industify
$project_video_text = esc_html__('See Our Work Process', 'industify');
if(isset($industify_fn_option['project_video_text'])){
	$project_video_text = $industify_fn_option['project_video_text'];
}

if(isset($industify_fn_option['project_single_caption'])){
	$industify_fn_portfolio_caption = $industify_fn_option['project_single_caption'];
}else{
	$industify_fn_portfolio_caption = 'disable';
}

if(isset($industify_fn_option['project_single_layout'])){
	$portfolio_single_layout = $industify_fn_option['project_single_layout'];
}else{
	$portfolio_single_layout = 'justified';
}
if(isset($_GET['project_single_layout'])){$portfolio_single_layout = $_GET['project_single_layout'];}

$industify_fn_portfolio_images = '';
// Post Thumbnail		
$postid = get_the_ID();
$post_thumbnail_id = get_post_thumbnail_id( $postid );
$src = wp_get_attachment_image_src( $post_thumbnail_id, 'industify_fn_thumb-720-9999');

// Categories
$industify_fn_post_cats = industify_fn_taxanomy_list($postid, 'project_category', false);


// Attached Images
if(function_exists('rwmb_meta')){
	$industify_fn_portfolio_images 			= rwmb_meta( 'industify_fn_portfolio_images', 'type=image&size=full' );
}
// CHeck if page is password protected	
if(post_password_required($post)){
	echo '<div class="industify_fn_password_protected">
		 	<div class="container">
				<div class="in">
					<div class="message_holder">
						<h1>'.esc_html__('Protected','industify').'</h1>
						<h3>'.esc_html__('This page was protected','industify').'</h3>
						'.get_the_password_form().'
						<div class="icon_holder"><i class="xcon-lock"></i></div>
					</div>
				</div>
		  	</div>
		  </div>';
}
else
{

if (have_posts()) : while (have_posts()) : the_post();
?>

<?php 
	
	// if the portfolio single contains video
	$video_detail = '';
	if(function_exists('rwmb_meta')){
	$video_detail = rwmb_meta( 'industify_fn_portfolio_video_detail' );
	}
	$playIconSvg	= '<img class="industify_fn_svg" src="'.get_template_directory_uri() .'/framework/svg/play-video.svg" alt="'.esc_attr__("svg", "industify").'" />';
	
	
	// portfolio details as list
	$li = '';
	$details = array();
	if(function_exists('rwmb_meta')){
		$details = rwmb_meta( 'industify_fn_portfolio_details' );
	}
	if(!empty($details)){
		foreach ( $details as $detail ) {
			if($detail[0] !== ''){
				$li	.= '<li>';
				$li .= '<p>'.$detail[0].'</p>';
				$li .= '<span>'.$detail[1].'</span>';
				$li	.= '</li>';
			}
		}
	}
?>
<div class="industify_fn_all_pages_content portfolio_single">
	<?php if($industify_fn_pagetitle !== 'disable' && $portfolio_single_layout !== 'justified'){ ?>
		<!-- PAGE TITLE -->
		<div class="industify_fn_pagetitle">
			<div class="container">
				<div class="title_holder">
					<h3><?php the_title(); ?></h3>
					<?php industify_fn_breadcrumbs();?>
				</div>
			</div>
		</div>
		<!-- /PAGE TITLE -->
	<?php } ?>


	<!-- ALL PAGES -->		
	<div class="industify_fn_all_pages">
		<div class="industify_fn_all_pages_inner">

			<?php if($portfolio_single_layout == 'justified'){ ?>
			<?php 
				$jheight = '300';
				if(isset($industify_fn_option['ps_j_imgh'])){
					$jheight = $industify_fn_option['ps_j_imgh'];
				}
				$jgutter = '10';
				if(isset($industify_fn_option['ps_j_gutter'])){
					$jgutter = $industify_fn_option['ps_j_gutter'];
				}
				if(isset($_GET['height'])){$jheight = $_GET['height'];}
				if(isset($_GET['gutter'])){$jgutter = $_GET['gutter'];}
			?>
			<div class="industify_fn_portfolio_justified" data-gutter="<?php echo esc_attr($jgutter);?>">
				<div class="j_list">
					<div class="j_list_in industify_fn_justified_images frenify_fn_lightbox" data-just-h="<?php echo esc_attr($jheight); ?>" data-just-g="<?php echo esc_attr($jgutter);?>">
					<?php
					if($industify_fn_portfolio_images)
					{   
						foreach($industify_fn_portfolio_images as $img){

							$src 	= wp_get_attachment_image_src( $img['ID'], 'industify_fn_thumb-9999-700' );
							$src 	= $src[0];
							$src2 	= wp_get_attachment_image_src( $img['ID'], 'full' );
							$src2 	= $src2[0];

							$playicon	= '';
							$video_url 	= get_post_meta( $img['ID'], '_image_video_url', true );
							$plus 		= '<span class="plus"></span>';
							if($video_url !== ''){
								$src2		= $video_url;
								$iconImg 	= '<img class="industify_fn_svg" src="'.get_template_directory_uri() .'/framework/svg/play-video.svg" alt="'.esc_attr__("svg", "industify").'" />';
								$overlay	= '<div class="industify_fn_videoitem_overlay"></div>';
								$playicon	= '<span class="industify_fn_videoitem">'.$iconImg.'</span>'.$overlay;
								$plus		= '';
							}
							?>
							<a class="lightbox" href="" data-src="<?php echo esc_url($src2);?>" data-sub-html="">
								<img src="<?php echo esc_url($src); ?>" alt="<?php  esc_attr(bloginfo('description')); ?>" />
								<?php echo wp_kses_post($playicon); ?>
								<?php echo wp_kses_post($plus); ?>
								<!-- CAPTION -->
								<?php if($industify_fn_portfolio_caption === 'enable'){ ?>
								<div class="industify_fn_hovercaption">
									<h3><?php echo esc_html($img['title']);?></h3>
									<h5><?php echo esc_html($img['caption']);?></h5>
								</div>
								<?php } ?>
								<!-- /CAPTION -->
							</a><?php

						 } 
					}?>
					</div>
				</div>
				
				<div class="j_content" <?php echo esc_attr($industify_fn_page_spaces); ?>>
					<div class="container">
						<div class="j_content_in">
							
							<div class="content_part">
								<div class="title_holder">
									<h3><?php the_title(); ?></h3>
								</div>
								<div class="content_holder">
									<?php the_content(); ?>
								</div>
								<div class="share_box">
									<?php get_template_part( 'inc/industify_fn_sharebox_post'); ?>
								</div>
								
								<?php if( !empty($video_detail) ) { ?>
								<div class="video_holder frenify_fn_lightbox">
									<div class="lightbox" data-src="<?php echo esc_url($video_detail); ?>">
										<span class="play_icon">
											<?php echo wp_kses_post($playIconSvg); ?>
										</span>
										<span class="play_text"><span><?php echo esc_html($project_video_text); ?></span></span>
									</div>
								</div>
								<?php }?>
								
								
								<?php 
									$prevnext		= '';
									$previous_post 	= get_adjacent_post(false, '', true);
									$next_post 		= get_adjacent_post(false, '', false);

									if ($previous_post && $next_post) { 
										$prevnext	= 'yes';
									}else if(!$previous_post && $next_post){
										$prevnext	= 'next';
									}else if($previous_post && !$next_post){
										$prevnext	= 'prev';
									}else{
										$prevnext	= 'no';
									}
								?>
								
								<!-- PREVIOUS-NEXT BOX -->
								<div class="industify_fn_prevnext" data-switch="<?php echo esc_attr($prevnext); ?>">
									<ul>
										<li class="prev"><?php $prevtext = __('Prev', 'industify'); previous_post_link( '%link',$prevtext ) ?></li>
										<li class="h_prev">
											<span><?php esc_html_e('Prev', 'industify');?></span>
										</li>
										<li class="next"><?php $nexttext = __('Next', 'industify'); next_post_link('%link',$nexttext) ?></li>
										<li class="h_next">
											<span><?php esc_html_e('Next', 'industify');?></span>
										</li>
									</ul>
								</div>
								<!-- /PREVIOUS-NEXT BOX -->
								
							</div>
							<?php if($li != ''){?>
							<div class="helpful_part">
								<div class="hp_inner">
									<ul>
										<?php if($industify_fn_post_cats !== '' || $industify_fn_post_cats !== 'undefined'){ ?>
											<li>
												<p><?php esc_html_e('Category', 'industify'); ?></p>
												<span><?php echo wp_kses_post($industify_fn_post_cats);?></span>
											</li>
										<?php } ?>
										<?php echo wp_kses_post($li);?>
									</ul>
								</div>
							</div>
							<?php }?>
						</div>
					</div>
				</div>
				
			</div>
			<?php }else{ ?>
			
			<!-- WITH SIDEBAR -->
			<div class="container">
				<div class="industify_fn_sidebarpage">
					<div class="inner">

						<div class="industify_fn_leftsidebar frenify_fn_sticky_sidebar" <?php echo esc_attr($industify_fn_page_spaces); ?>>
							<div class="industify_fn_portfolio_single_list frenify_fn_lightbox">
								<?php
								if($industify_fn_portfolio_images){   

									foreach($industify_fn_portfolio_images as $img){

										$src 	= wp_get_attachment_image_src( $img['ID'], 'industify_fn_thumb-720-9999' );
										$src 	= $src[0];

										$src2 	= wp_get_attachment_image_src( $img['ID'], 'full' );
										$src2 	= $src2[0];

										$playicon	= '';
										$video_url 	= get_post_meta( $img['ID'], '_image_video_url', true );
										$plus 		= '<span class="plus"></span>';
										if($video_url !== ''){
											$src2		= $video_url;
											$iconImg 	= '<img class="industify_fn_svg" src="'.get_template_directory_uri() .'/framework/svg/play-video.svg" alt="'.esc_attr__("svg", "industify").'" />';
											$overlay	= '<div class="industify_fn_videoitem_overlay"></div>';
											$playicon	= '<span class="industify_fn_videoitem">'.$iconImg.'</span>'.$overlay;
											$plus		= '';
										}
										$forLG 	= '<img src="'.esc_url($src).'" alt="'.esc_attr__('lg', 'industify').'" />';
										?>
									<div class="item lightbox" data-src="<?php echo esc_url($src2); ?>">
										<?php echo wp_kses_post($forLG);?>
										<?php echo wp_kses_post($playicon); ?>
										<?php echo wp_kses_post($plus); ?>

										<!-- CAPTION -->
										<?php if($industify_fn_portfolio_caption === 'enable'){ ?>
										<div class="industify_fn_hovercaption">
											<h3><?php echo esc_html($img['title']);?></h3>
											<h5><?php echo esc_html($img['caption']);?></h5>
										</div>
										<?php } ?>
										<!-- /CAPTION -->

									</div><?php

								 } 
							}?>
							</div>

						</div>

						<div class="industify_fn_rightsidebar frenify_fn_sticky_sidebar" <?php echo esc_attr($industify_fn_page_spaces); ?>>
							<div class="industify_fn_portfolio_details">
								<div class="share_box">
									<?php get_template_part( 'inc/industify_fn_sharebox_post'); ?>
								</div>
								<div class="info_list">
									<ul>
										<?php if($industify_fn_post_cats !== '' || $industify_fn_post_cats !== 'undefined'){ ?>
											<li>
												<p><?php esc_html_e('Category', 'industify'); ?></p>
												<span><?php echo wp_kses_post($industify_fn_post_cats);?></span>
											</li>
										<?php } ?>
										<?php 
											echo wp_kses_post($li);
										?>
									</ul>
								</div>
								<div class="content_holder">
									<?php the_content(); ?>
								</div>
								<?php if( !empty($video_detail) ) { ?>
								<div class="video_holder frenify_fn_lightbox">
									<div class="lightbox" data-src="<?php echo esc_url($video_detail); ?>">
										<span class="play_icon">
											<?php echo wp_kses_post($playIconSvg); ?>
										</span>
										<span class="play_text"><span><?php echo esc_html($project_video_text); ?></span></span>
									</div>
								</div>
								<?php }?>
							</div>

						</div>
					</div>
				</div>
			</div>
			<!-- /WITH SIDEBAR -->
			<?php } ?>

			<?php endwhile; endif; ?>

		</div>
	</div>		
	<!-- /ALL PAGES -->
</div>
<?php } ?>

<?php get_footer(); ?>  