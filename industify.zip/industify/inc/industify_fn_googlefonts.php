<?php
function industify_fn_fonts() {
	global $industify_fn_option;
	$customfont = '';
	
	$default = array(
					'arial',
					'verdana',
					'trebuchet',
					'georgia',
					'times',
					'tahoma',
					'helvetica');
	
	
	$bodyFont			= 'Open Sans';
	$navFont			= 'Rubik';
	$navMobFont			= 'Montserrat';
	$headingFont		= 'Rubik';
	$blockquoteFont		= 'Lora';
	$extraFont			= 'Montserrat';
	
	if(isset($industify_fn_option['body_font']['font-family'])){
		$bodyFont		= $industify_fn_option['body_font']['font-family'];
	}
	if(isset($industify_fn_option['nav_font']['font-family'])){
		$navFont		= $industify_fn_option['nav_font']['font-family'];
	}
	if(isset($industify_fn_option['nav_mob_font']['font-family'])){
		$navMobFont		= $industify_fn_option['nav_mob_font']['font-family'];
	}
	if(isset($industify_fn_option['heading_font']['font-family'])){
		$headingFont	= $industify_fn_option['heading_font']['font-family'];
	}
	if(isset($industify_fn_option['blockquote_font']['font-family'])){
		$blockquoteFont	= $industify_fn_option['blockquote_font']['font-family'];
	}
	if(isset($industify_fn_option['extra_font']['font-family'])){
		$extraFont		= $industify_fn_option['extra_font']['font-family'];
	}
	$googlefonts = array(
					$bodyFont,
					$navFont,
					$navMobFont,
					$headingFont,
					$blockquoteFont,
					$extraFont,
					);
	
	foreach($googlefonts as $getfonts) {
		
		if(!in_array($getfonts, $default)) {
				$customfont = str_replace(' ', '+', $getfonts). ':400,400italic,500,500italic,600,600italic,700,700italic|' . $customfont;
		}
	}
	
	
	
	
	if($customfont != '' && isset($industify_fn_option)){
		$protocol = is_ssl() ? 'https' : 'http';
		wp_enqueue_style( 'industify_fn_googlefonts', "$protocol://fonts.googleapis.com/css?family=" . substr_replace($customfont ,"",-1) . "&subset=latin,cyrillic,greek,vietnamese" );
	}	
}
add_action( 'wp_enqueue_scripts', 'industify_fn_fonts' );
?>