<?php 
	global $industify_fn_option;

	$postid = get_the_ID();
	$post_thumbnail_id = get_post_thumbnail_id( $postid );
	$src = wp_get_attachment_image_src( $post_thumbnail_id, 'full');
	if(isset($src[0])){
		$image = '<img src="'.esc_url($src[0]).'" />';
	}
	
	if(has_post_thumbnail() && isset($image)){
?>
<div class="fn-format-img">
	<div class="time">
		<span></span>
		<h3><?php the_time('d');?></h3>
		<h5><?php the_time('M');?></h5>
		<h5><?php the_time('Y');?></h5>
	</div>
	<span class="shape1"></span>
	<span class="shape2"></span>
	<?php echo wp_kses_post($image);?>
</div>
<?php } ?>