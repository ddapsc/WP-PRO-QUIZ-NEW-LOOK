<?php 
	global $industify_fn_option, $post;
	
	$main_nav 	= array('theme_location'  => 'main_menu','menu_class' => 'industify_fn_main_nav vert_nav');

?>
   
<!-- HEADER -->
<header class="industify_fn_header_sticky on">


	<div class="sticky_list">	
		<?php if(has_nav_menu('main_menu')){ wp_nav_menu( $main_nav );}?>
	</div>


</header>
<!-- /HEADER --> 