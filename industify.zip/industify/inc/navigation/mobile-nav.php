<?php 
	global $industify_fn_option, $post;

	$mobile_nav 				= array('theme_location'  => 'mobile_menu','menu_class' => 'vert_menu_list nav_ver','menu_id' => 'vert_menu_list');
	$mobileLogo 				= get_template_directory_uri().'/framework/img/mobile-logo.png';

	$logoMobile 				= $logoMobileURL = '';
	if(isset($industify_fn_option['retina_logo_light'])){
		$logoMobile 			= $industify_fn_option['retina_logo_light'];
	}
	if(isset($industify_fn_option['retina_logo_light']['url'])){
		$logoMobileURL 			= $industify_fn_option['retina_logo_light']['url'];
	}
	if(isset($logoMobile) && isset($logoMobileURL)){
		if($logoMobileURL !== ''){
			$mobileLogo 		= $logoMobileURL;
		}
	}
?>
<!-- MOBILE MENU -->
<div class="industify_fn_mobilemenu_wrap">
	<?php echo industify_fn_topPanel(); ?>
	<?php
		if(isset($industify_fn_option['topbar_switch']) && ($industify_fn_option['topbar_switch'] === 'enable')){
			get_template_part( 'inc/navigation/toll-free-mobile');
		}
	?>

	<!-- LOGO & HAMBURGER -->
	<div class="logo_hamb">
		<div class="in">
			<div class="menu_logo">
				<a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url($mobileLogo);?>" alt="<?php esc_attr(bloginfo('description')); ?>" /></a>
			</div>
			<div class="hamburger hamburger--collapse-r">
				<div class="hamburger-box">
					<div class="hamburger-inner"></div>
				</div>
			</div>
		</div>
	</div>
	<!-- /LOGO & HAMBURGER -->

	<!-- MOBILE DROPDOWN MENU -->
	<div class="mobilemenu">
		<?php if(has_nav_menu('mobile_menu')){ wp_nav_menu( $mobile_nav );}?>
	</div>
	<!-- /MOBILE DROPDOWN MENU -->

</div>
<!-- /MOBILE MENU -->