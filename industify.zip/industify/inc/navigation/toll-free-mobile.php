<?php 
	global $industify_fn_option, $post;
?>
<!-- TOLL FREE MOBILE -->
<div class="m_toll_free_lang">
			
	<?php if(isset($industify_fn_option['lang_switch']) && ($industify_fn_option['lang_switch'] === 'enable')){ ?>
	<?php echo industify_fn_custom_lang_switcher();?>
	<?php } ?>

	<?php 
		if(isset($industify_fn_option['tollfree_switch']) && ($industify_fn_option['tollfree_switch'] === 'enable')){
			$toll_img = get_template_directory_uri().'/framework/img/call.png';
			$toll_img_config = $toll_img_configURL = '';
			if(isset($industify_fn_option['topbar_img'])){
				$toll_img_config 	= $industify_fn_option['topbar_img'];
			}
			if(isset($industify_fn_option['topbar_img']['url'])){
				$toll_img_configURL = $industify_fn_option['topbar_img']['url'];
			}
			if(isset($toll_img_config) && isset($toll_img_configURL)){
				if($toll_img_configURL !== ''){
					$toll_img = $toll_img_configURL;
				}
			}
	?>
	<div class="m_toll_free">
		<span class="shape1"></span>
		<span class="shape2"></span>
		<span class="shape3"></span>
		<div class="tf_in">
			<div class="img_holder" data-fn-bg-img="<?php echo esc_url($toll_img);?>"></div>
			<p>
				<?php if(isset($industify_fn_option['toll_free_text'])){ ?>
						<span>
							<?php echo wp_kses_post($industify_fn_option['toll_free_span']); ?>
						</span>
						<?php echo wp_kses_post($industify_fn_option['toll_free_text']);
					}else{
					?>
						<span>
							<?php esc_html_e('Toll Free:', 'industify'); ?>
						</span>
						1-800-987-6543<?php 
					}
				?>
			</p>
		</div>
	</div>
	<?php } ?>
</div>
<!-- /TOLL FREE MOBILE -->