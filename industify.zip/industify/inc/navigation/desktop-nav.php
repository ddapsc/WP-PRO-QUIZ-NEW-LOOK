<?php 
	global $industify_fn_option, $post;

	// NAVIGATIONS ----------------------------------------------------------------------------------
	$main_nav 					= array('theme_location'  => 'main_menu','menu_class' => 'industify_fn_main_nav vert_nav');
	
	// LOGO ----------------------------------------------------------------------------------
	$defaultLogo 				= get_template_directory_uri().'/framework/img/desktop-light-logo.png';
	$retinaLogo 				= get_template_directory_uri().'/framework/img/retina-light-logo.png';
	$defaultLogoDark 			= get_template_directory_uri().'/framework/img/desktop-dark-logo.png';
	$retinaLogoDark 			= get_template_directory_uri().'/framework/img/retina-dark-logo.png';
	
	$logoDesktop 				= $logoDesktopURL = '';
	if(isset($industify_fn_option['desktop_logo_dark'])){
		$logoDesktop 			= $industify_fn_option['desktop_logo_dark'];
	}
	if(isset($industify_fn_option['desktop_logo_dark']['url'])){
		$logoDesktopURL 		= $industify_fn_option['desktop_logo_dark']['url'];
	}
	if(isset($logoDesktop) && isset($logoDesktopURL)){
		if($logoDesktopURL !== ''){
			$defaultLogo 		= $logoDesktopURL;
		}
	}
	
	// since industify
	$logoDesktopDark 			= $logoDesktopURLDark = '';
	if(isset($industify_fn_option['desktop_logo_light'])){
		$logoDesktopDark 		= $industify_fn_option['desktop_logo_light'];
	}
	if(isset($industify_fn_option['desktop_logo_light']['url'])){
		$logoDesktopURLDark 	= $industify_fn_option['desktop_logo_light']['url'];
	}
	if(isset($logoDesktopDark) && isset($logoDesktopURLDark)){
		if($logoDesktopURLDark !== ''){
			$defaultLogoDark = $logoDesktopURLDark;
		}
	}
	

	
	$logoRetina 				= $logoRetinaURL = '';
	if(isset($industify_fn_option['retina_logo_light'])){
		$logoRetina 			= $industify_fn_option['retina_logo_light'];
	}
	if(isset($industify_fn_option['retina_logo_light']['url'])){
		$logoRetinaURL 			= $industify_fn_option['retina_logo_light']['url'];
	}
	if(isset($logoRetina) && isset($logoRetinaURL)){
		if($logoRetinaURL !== ''){
			$retinaLogo 		= $logoRetinaURL;
		}
	}
	
	// since industify
	$logoRetinaDark 			= $logoRetinaURLDark = '';
	if(isset($industify_fn_option['retina_logo_dark'])){
		$logoRetinaDark 		= $industify_fn_option['retina_logo_dark'];
	}
	if(isset($industify_fn_option['retina_logo_dark']['url'])){
		$logoRetinaURLDark 		= $industify_fn_option['retina_logo_dark']['url'];
	}
	if(isset($logoRetinaDark) && isset($logoRetinaURLDark)){
		if($logoRetinaURLDark !== ''){
			$retinaLogoDark 	= $logoRetinaURLDark;
		}
	}
	
	// since v1.2.6
	// 05.08.2020
	if(isset($_GET['logo'])){
		$defaultLogo = $defaultLogoDark = $retinaLogo = $retinaLogoDark = $_GET['logo'];
	}
?>
<!-- HEADER -->
<div class="industify_fn_header">
	
	<?php echo industify_fn_topPanel(); ?>
	
	<div class="header_inner">
		<div class="menu_logo">
			<a href="<?php echo esc_url(home_url('/')); ?>">
				<img class="desktop_logo" src="<?php echo esc_url($defaultLogo);?>" alt="<?php esc_attr(bloginfo('description')); ?>" />
				<img class="desktop_logo_dark" src="<?php echo esc_url($defaultLogoDark);?>" alt="<?php esc_attr(bloginfo('description')); ?>" />
				<img class="retina_logo" src="<?php echo esc_url($retinaLogo);?>" alt="<?php esc_attr(bloginfo('description')); ?>" />
				<img class="retina_logo_dark" src="<?php echo esc_url($retinaLogoDark);?>" alt="<?php esc_attr(bloginfo('description')); ?>" />
				<span><span class="span_a"></span><span class="span_b"></span></span>
			</a>
		</div>
		<div class="menu_nav">

			<?php if(has_nav_menu('main_menu')){ wp_nav_menu( $main_nav );}?>

		</div>

		<?php if(isset($industify_fn_option['topbar_switch']) && ($industify_fn_option['topbar_switch'] === 'enable')){ ?>
		<div class="toll_free_lang">

			<?php if(isset($industify_fn_option['lang_switch']) && ($industify_fn_option['lang_switch'] === 'enable')){ ?>
			<?php echo industify_fn_custom_lang_switcher();?>
			<?php } ?>


			<?php if(isset($industify_fn_option['tollfree_switch']) && ($industify_fn_option['tollfree_switch'] === 'enable')){ ?>
			<div class="toll_free">
				<span class="shape1"></span>
				<span class="shape2"></span>
				<span class="shape3"></span>
				<div class="tf_in">
					<?php 
						$toll_img = get_template_directory_uri().'/framework/img/call.png';
						$toll_img_config = $toll_img_configURL = '';
						if(isset($industify_fn_option['topbar_img'])){
							$toll_img_config 	= $industify_fn_option['topbar_img'];
						}
						if(isset($industify_fn_option['topbar_img']['url'])){
							$toll_img_configURL = $industify_fn_option['topbar_img']['url'];
						}
						if(isset($toll_img_config) && isset($toll_img_configURL)){
							if($toll_img_configURL !== ''){
								$toll_img = $toll_img_configURL;
							}
						}
					?>
					<div class="img_holder" data-fn-bg-img="<?php echo esc_url($toll_img);?>"></div>
					<p>
						<?php 	
							if(isset($industify_fn_option['toll_free_text'])){
						?>
								<span><?php echo wp_kses_post($industify_fn_option['toll_free_span']); ?></span>
								<?php echo wp_kses_post($industify_fn_option['toll_free_text']);
							}else{?>
								<span><?php esc_html_e('Toll Free:', 'industify'); ?></span>1-800-987-6543
						<?php }?>
					</p>
				</div>
			</div>
			<?php } ?>
		</div>
		<?php } ?>

	</div>
</div>
<!-- /HEADER --> 