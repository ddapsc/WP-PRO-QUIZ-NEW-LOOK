<?php

	add_action( 'after_setup_theme', 'industify_fn_setup', 50 );

	function industify_fn_setup(){

			// REGISTER THEME MENU
			if(function_exists('register_nav_menus')){
				register_nav_menus(array('main_menu' 	=> esc_html__('Main Menu','industify')));
				register_nav_menus(array('mobile_menu' 	=> esc_html__('Mobile Menu','industify')));
			}

			// This theme styles the visual editor with editor-style.css to match the theme style.
			add_action( 'wp_enqueue_scripts', 'industify_fn_scripts', 100 ); 
			add_action( 'wp_enqueue_scripts', 'industify_fn_styles', 100 );
			add_action( 'wp_enqueue_scripts', 'industify_fn_inline_styles', 150 );
			add_action( 'admin_enqueue_scripts', 'industify_fn_admin_scripts' );
		
			// Actions
			add_action( 'tgmpa_register', 'industify_fn_register_required_plugins' );
		
			// Post Format support. You can also use the legacy "gallery" or "asides" (note the plural) categories.
			add_theme_support( 'post-formats', array('video','audio','gallery','image','link','quote') );
		
			// This theme uses post thumbnails
			add_theme_support( 'post-thumbnails' );
		
			set_post_thumbnail_size( 300, 300, true ); 									// Normal post thumbnails
		
			add_image_size( 'industify_fn_thumb-1000-1000', 1000, 1000, true);		// Portfolio Categories
			add_image_size( 'industify_fn_thumb-1000-9999', 1000, 9999, false);		// Portfolio Page
			add_image_size( 'industify_fn_thumb-300-300', 300, 300, true);			// Clients, Commentary
		
			//Load Translation Text Domain
			load_theme_textdomain( 'industify', get_template_directory() . '/languages' );
		
			// Firing Title Tag Function
			industify_fn_theme_slug_setup();
		
			add_filter(	'widget_tag_cloud_args', 'industify_fn_tag_cloud_args');
		
			if ( ! isset( $content_width ) ) $content_width = 1170;
		
			// Add default posts and comments RSS feed links to head
			add_theme_support( 'automatic-feed-links' );
			add_theme_support( 'wp_list_comments' );
		
			add_editor_style() ;
			
			// for ajax
			add_action( 'wp_ajax_nopriv_industify_fn_ajax_service_list', 'industify_fn_ajax_service_list' );
			add_action( 'wp_ajax_industify_fn_ajax_service_list', 'industify_fn_ajax_service_list' );
			
			// for ajax woocommerce
			add_action( 'wp_ajax_nopriv_industify_fn_remove_item_from_cart', 'industify_fn_remove_item_from_cart' );
			add_action( 'wp_ajax_industify_fn_remove_item_from_cart', 'industify_fn_remove_item_from_cart' );
			
			$my_theme 		= wp_get_theme( 'industify' );
			$version		= '1.0';
			if ( $my_theme->exists() ){
				$version 	= (string)$my_theme->get( 'Version' );
			}
			$version		= 'ver_'.$version;
			define('INDUSTIFY_VER', $version);
			define('INDUSTIFY_URL', get_template_directory_uri());
		/* ------------------------------------------------------------------------ */
		/*  Inlcudes
		/* ------------------------------------------------------------------------ */
			include_once( get_template_directory().'/inc/industify_fn_functions.php'); 		// Custom Functions
			include_once( get_template_directory().'/inc/industify_fn_googlefonts.php'); 	// Google Fonts Init
			include_once( get_template_directory().'/inc/industify_fn_css.php'); 			// Inline CSS
			include_once( get_template_directory().'/inc/industify_fn_sidebars.php'); 		// Widget Area
			include_once( get_template_directory().'/inc/industify_fn_pagination.php'); 	// Pagination
			include_once( get_template_directory().'/config/config-woo/config.php'); 		// WooCommerce	
		
			include_once( get_template_directory().'/inc/widgets/widget-business-hours.php');	// Load Widgets
			include_once( get_template_directory().'/inc/widgets/widget-estimate.php');			// Load Widgets
			include_once( get_template_directory().'/inc/widgets/widget-brochure.php');			// Load Widgets
			
	}




/* ----------------------------------------------------------------------------------- */
/*  ENQUEUE STYLES AND SCRIPTS
/* ----------------------------------------------------------------------------------- */
	function industify_fn_scripts() {
		wp_enqueue_script('modernizr-custom', INDUSTIFY_URL . '/framework/js/modernizr-custom.js', array('jquery'), INDUSTIFY_VER, FALSE);
		wp_enqueue_script('theia-sticky-sidebar', INDUSTIFY_URL . '/framework/js/theia-sticky-sidebar.js', array('jquery'), INDUSTIFY_VER, TRUE);
		wp_enqueue_script('isotope', INDUSTIFY_URL . '/framework/js/isotope.js', array('jquery'), INDUSTIFY_VER, TRUE);
		wp_enqueue_script('select2', INDUSTIFY_URL . '/framework/js/select2.js', array('jquery'), INDUSTIFY_VER, TRUE);
		wp_enqueue_script('justified', INDUSTIFY_URL . '/framework/js/justified.js', array('jquery'), INDUSTIFY_VER, TRUE);
		wp_enqueue_script('lightgallery', INDUSTIFY_URL . '/framework/js/lightgallery.js', array('jquery'), INDUSTIFY_VER, TRUE);
		wp_enqueue_script('magnific-popup', INDUSTIFY_URL . '/framework/js/magnific-popup.js', array('jquery'), INDUSTIFY_VER, TRUE);
		wp_enqueue_script('owl-carousel', INDUSTIFY_URL . '/framework/js/owl-carousel.js', array('jquery'), INDUSTIFY_VER, TRUE);
		wp_enqueue_script('industify-fn-woocommerce', INDUSTIFY_URL.'/config/config-woo/woocommerce.js', array('jquery'), INDUSTIFY_VER, TRUE);
		wp_enqueue_script('industify-fn-init', INDUSTIFY_URL . '/framework/js/init.js', array('jquery'), INDUSTIFY_VER, TRUE);
		wp_localize_script( 'industify-fn-init', 'fn_ajax_object', array( 
			'fn_ajax_url' 	=> admin_url( 'admin-ajax.php' ),
			'siteurl' 		=> site_url() // added since v1.3.3
		));
		if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
	}
	
	function industify_fn_admin_scripts() {
		wp_enqueue_script('widget-upload', INDUSTIFY_URL . '/framework/js/widget-upload.js', array('jquery'), INDUSTIFY_VER, FALSE);
		wp_enqueue_script('industify-fn-meta-sortable', INDUSTIFY_URL . '/framework/js/meta-sortable.js', array('jquery'), INDUSTIFY_VER, FALSE);
		wp_enqueue_style('industify-fn-meta-sortable', INDUSTIFY_URL.'/framework/css/meta-sortable.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('industify-fn-admin-style', INDUSTIFY_URL.'/framework/css/admin-style.css', array(), INDUSTIFY_VER, 'all');
	}

	function industify_fn_styles(){
		wp_enqueue_style('industify-fn-font-url', industify_fn_font_url(), array(), null );
		wp_enqueue_style('industify-fn-base', INDUSTIFY_URL.'/framework/css/base.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('industify-fn-skeleton', INDUSTIFY_URL.'/framework/css/skeleton.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('fontello', INDUSTIFY_URL.'/framework/css/fontello.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('justified', INDUSTIFY_URL.'/framework/css/justified.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('select2', INDUSTIFY_URL.'/framework/css/select2.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('magnific-popup', INDUSTIFY_URL.'/framework/css/magnific-popup.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('lightgallery', INDUSTIFY_URL.'/framework/css/lightgallery.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('owl-carousel', INDUSTIFY_URL.'/framework/css/owl-carousel.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('owl-theme-default', INDUSTIFY_URL.'/framework/css/owl-theme-default.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('industify-fn-woocommerce', INDUSTIFY_URL.'/config/config-woo/woocommerce.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('industify-fn-rtl-stylesheet', INDUSTIFY_URL.'/framework/css/rtl-style.css', array(), INDUSTIFY_VER, 'all');
		wp_enqueue_style('industify-fn-stylesheet', get_stylesheet_uri(), array(), INDUSTIFY_VER, 'all' );
	}




/* ----------------------------------------------------------------------------------- */
/*  Title tag: works WordPress v4.1 and above
/* ----------------------------------------------------------------------------------- */
	function industify_fn_theme_slug_setup() {
		add_theme_support( 'title-tag' );
	}
/* ----------------------------------------------------------------------------------- */
/*  Tagcloud widget
/* ----------------------------------------------------------------------------------- */
	
	function industify_fn_tag_cloud_args($args)
	{
		
		$my_args = array('smallest' => 14, 'largest' => 14, 'unit'=>'px', 'orderby'=>'count', 'order'=>'DESC' );
		$args = wp_parse_args( $args, $my_args );
		return $args;
	}

	
/*-----------------------------------------------------------------------------------*/
/*	TGM Plugin Activation
/*-----------------------------------------------------------------------------------*/

require_once get_template_directory().'/plugin/class-tgm-plugin-activation.php';

function industify_fn_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => 'Industify Core', // The plugin name.
			'slug'               => 'industify-core', // The plugin slug (typically the folder name).
			'source'             => get_template_directory() . '/plugin/industify-core.zip', // The plugin source.
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),
		array(
			'name'               => 'Redux Framework', // The plugin name.
			'slug'               => 'redux-framework', // The plugin slug (typically the folder name).
			'source'             => 'https://github.com/reduxframework/redux-framework/archive/master.zip', // The plugin source.
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'external_url'       => 'https://github.com/reduxframework/redux-framework', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),
		array(
			'name'               => 'Elementor', // The plugin name.
			'slug'               => 'elementor', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),
		array(
			'name'               => 'Categorify', // The plugin name.
			'slug'               => 'categorify', // The plugin slug (typically the folder name).
			'required'           => false, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),
		array(
			'name'               => 'Opt In Hound', // The plugin name.
			'slug'               => 'opt-in-hound', // The plugin slug (typically the folder name).
			'source'             => get_template_directory() . '/plugin/opt-in-hound.zip', // The plugin source.
			'required'           => false, // If false, the plugin is only 'recommended' instead of required.
			'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
			'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
			'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
			'external_url'       => '', // If set, overrides default API URL and points to an external URL.
			'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
		),

	);

	/*
	 * Array of configuration settings. Amend each line as needed.
	 *
	 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
	 * strings available, please help us make TGMPA even better by giving us access to these translations or by
	 * sending in a pull-request with .po file(s) with the translations.
	 *
	 * Only uncomment the strings in the config array if you want to customize the strings.
	 */
	$config = array(
		'id'           => 'industify',            // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.
	);

	tgmpa( $plugins, $config );
}



?>