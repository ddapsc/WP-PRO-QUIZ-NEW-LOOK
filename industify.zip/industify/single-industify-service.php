<?php

get_header();

global $post, $industify_fn_option;
$industify_fn_pagetitle = '';
$industify_fn_top_padding = '';
$industify_fn_bot_padding = '';
$industify_fn_page_spaces = '';
$industify_fn_pagestyle = '';

if(function_exists('rwmb_meta')){
	$industify_fn_pagetitle 			= get_post_meta(get_the_ID(),'industify_fn_page_title', true);
	$industify_fn_top_padding 		= get_post_meta(get_the_ID(),'industify_fn_page_padding_top', true);
	$industify_fn_bot_padding 		= get_post_meta(get_the_ID(),'industify_fn_page_padding_bottom', true);
	
	$industify_fn_page_spaces = 'style=';
	if($industify_fn_top_padding != ''){$industify_fn_page_spaces .= 'padding-top:'.$industify_fn_top_padding.'px;';}
	if($industify_fn_bot_padding != ''){$industify_fn_page_spaces .= 'padding-bottom:'.$industify_fn_bot_padding.'px;';}
	if($industify_fn_top_padding == '' && $industify_fn_bot_padding == ''){$industify_fn_page_spaces = '';}
	
	// page styles
	$industify_fn_pagestyle 			= get_post_meta(get_the_ID(),'industify_fn_page_style', true);
}
// CHeck if page is password protected	
if(post_password_required($post)){
	echo '<div class="industify_fn_password_protected">
		 	<div class="in">
				<div>
					<div class="message_holder">
						<h1>'.esc_html__('Protected','industify').'</h1>
						<h3>'.esc_html__('This page was protected','industify').'</h3>
						'.get_the_password_form().'
						<div class="icon_holder"><i class="xcon-lock"></i></div>
					</div>
				</div>
		  	</div>
		  </div>';
}
else
{

?>
<div class="industify_fn_all_pages_content service_single">


	<!-- ALL PAGES -->		
	<div class="industify_fn_all_pages">
		<div class="industify_fn_all_pages_inner">


			<?php if($industify_fn_pagetitle !== 'disable'){ ?>
				<!-- PAGE TITLE -->
				<div class="container">
					<div class="industify_fn_pagetitle">
						<div class="title_holder">
							<h3><?php the_title(); ?></h3>
							<?php industify_fn_breadcrumbs();?>
						</div>
					</div>
				</div>
				<!-- /PAGE TITLE -->
			<?php } ?>

			<!-- WITH SIDEBAR -->
			<div class="industify_fn_sidebarpage">
				<div class="container">
					<div class="s_inner">

						<div class="industify_fn_leftsidebar" <?php echo esc_attr($industify_fn_page_spaces); ?>>
								
								
								<div class="lp_inner">
									<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

										<?php $postid 		= get_the_ID(); ?>
										<?php the_content(); ?>

										<?php if ( comments_open() || get_comments_number()){?>
										<!-- Comments -->
										<div class="industify_fn_comment" id="comments">
											<?php comments_template(); ?>
										</div>
										<!-- /Comments -->

									<?php } ?>
								</div>


								<div class="other_services">
									<h3><?php esc_html_e('Other Services', 'industify');?></h3>
									<div class="os_list">
										<ul>
									<?php
										// QUERY ARGUMENTS
										$other_services_perpage = 2;
										$query_args = array(
											'post_type' 			=> 'industify-service',
											'posts_per_page' 		=> $other_services_perpage,
											'post_status' 			=> 'publish',
											'orderby'				=> 'rand'
										);
										// QUERY WITH ARGUMENTS
										$industify_fn_loop = new WP_Query($query_args);

										if ($industify_fn_loop->have_posts()) : while ($industify_fn_loop->have_posts()) : $industify_fn_loop->the_post();
									?>
										<li>
											<div class="item">
												<div class="title">
													<h3><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
													<p><?php echo industify_fn_excerpt(30,get_the_id()); ?></p>
												</div>
												<div class="read_more">
													<a href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'industify'); ?></a>
												</div>
											</div>
										</li>
									<?php endwhile; endif;?>
									</ul>
									</div>
								</div>
						</div>

						<div class="industify_fn_rightsidebar" <?php echo esc_attr($industify_fn_page_spaces); ?>>
							<?php
								$commonClass 	= 'fn-service-'.$postid;
							?>
							<?php industify_fn_service_single_list(esc_attr($commonClass));?>
							<?php get_sidebar(); ?>
						</div>
					</div>
				</div>
			</div>
			<!-- /WITH SIDEBAR -->

			<?php endwhile; endif; ?>
		</div>
	</div>		
	<!-- /ALL PAGES -->
</div>
<?php } ?>

<?php get_footer(); ?>  